# Webtek-lab-MP2-OFFLINE-WEB-APP

Assigned members of the group in the area to work on: 
(Remember that you are not restricted to work only in 
that assigned area, but you must give a quality output
related to the assigned area you are in currently.
Once you are finished with your team, you may proceed 
with helping the teams)

Process Layout, HTML, & CSS (Front-end):
- Gloridhel
- Jennelyn
- Joy
- Vincent

Process Layout, HTML, & CSS (Back-end):
- Mark
- James
- Jom
- Allonah
- Arnaldo
